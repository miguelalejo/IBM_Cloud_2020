This Python package encapsulates custom sklearn pipeline transforms for use with the Watson Machine Learning API
